import { Hono } from "hono";
import { stmt } from "./db.ts";

const GITHUB_CLIENT_ID = process.env.GITHUB_CLIENT_ID || "";
const GITHUB_CLIENT_SECRET = process.env.GITHUB_CLIENT_SECRET || "";

export interface AuthUser {
  githubId: number;
  login: string;
  avatarUrl: string;
  deviceId: string;
}

const tokenCache = new Map<string, AuthUser>();

export async function resolveUser(token: string, deviceId: string): Promise<AuthUser | null> {
  const cached = tokenCache.get(token);
  if (cached && cached.deviceId === deviceId) return cached;

  const res = await fetch("https://api.github.com/user", {
    headers: { Authorization: `Bearer ${token}`, "User-Agent": "paimon-sync" },
  });
  if (!res.ok) return null;

  const gh = (await res.json()) as { id: number; login: string; avatar_url: string };
  const user: AuthUser = { githubId: gh.id, login: gh.login, avatarUrl: gh.avatar_url, deviceId };

  stmt.upsertUser.run(gh.id, gh.login, gh.avatar_url);
  stmt.upsertDevice.run(deviceId, gh.id, deviceId);
  tokenCache.set(token, user);
  return user;
}

export function authMiddleware() {
  return async (c: any, next: () => Promise<void>) => {
    const auth = c.req.header("Authorization");
    const deviceId = c.req.header("X-Device-Id");
    if (!auth?.startsWith("Bearer ") || !deviceId) {
      return c.json({ error: "unauthorized" }, 401);
    }
    const user = await resolveUser(auth.slice(7), deviceId);
    if (!user) return c.json({ error: "invalid token" }, 401);
    c.set("user", user);
    await next();
  };
}

export const authRouter = new Hono();

authRouter.post("/github", async (c) => {
  const { code } = await c.req.json<{ code: string }>();
  if (!code) return c.json({ error: "code required" }, 400);

  const tokenRes = await fetch("https://github.com/login/oauth/access_token", {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({
      client_id: GITHUB_CLIENT_ID,
      client_secret: GITHUB_CLIENT_SECRET,
      code,
    }),
  });

  const tokenData = (await tokenRes.json()) as { access_token?: string; error?: string };
  if (!tokenData.access_token) {
    return c.json({ error: tokenData.error || "token exchange failed" }, 400);
  }

  const userRes = await fetch("https://api.github.com/user", {
    headers: { Authorization: `Bearer ${tokenData.access_token}`, "User-Agent": "paimon-sync" },
  });
  if (!userRes.ok) return c.json({ error: "github user fetch failed" }, 400);

  const gh = (await userRes.json()) as { id: number; login: string; avatar_url: string };
  stmt.upsertUser.run(gh.id, gh.login, gh.avatar_url);

  return c.json({
    token: tokenData.access_token,
    user: { githubId: gh.id, login: gh.login, avatarUrl: gh.avatar_url },
  });
});

authRouter.post("/device-flow/start", async (c) => {
  const res = await fetch("https://github.com/login/device/code", {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ client_id: GITHUB_CLIENT_ID, scope: "read:user" }),
  });
  return c.json(await res.json());
});

authRouter.post("/device-flow/poll", async (c) => {
  const { device_code } = await c.req.json<{ device_code: string }>();
  const res = await fetch("https://github.com/login/oauth/access_token", {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({
      client_id: GITHUB_CLIENT_ID,
      device_code,
      grant_type: "urn:ietf:params:oauth:grant-type:device_code",
    }),
  });

  const data = (await res.json()) as { access_token?: string; error?: string; interval?: number };
  if (data.access_token) {
    const userRes = await fetch("https://api.github.com/user", {
      headers: { Authorization: `Bearer ${data.access_token}`, "User-Agent": "paimon-sync" },
    });
    const gh = (await userRes.json()) as { id: number; login: string; avatar_url: string };
    stmt.upsertUser.run(gh.id, gh.login, gh.avatar_url);
    return c.json({
      token: data.access_token,
      user: { githubId: gh.id, login: gh.login, avatarUrl: gh.avatar_url },
    });
  }
  return c.json(data);
});
