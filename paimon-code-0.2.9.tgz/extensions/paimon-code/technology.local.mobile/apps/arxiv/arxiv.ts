// arxiv.ts — Arxiv 论文搜索 (MobileApp)
import type { MobileApp } from "../../system.kernel/kernel.ts";
import { execSync } from "node:child_process";
import { join } from "node:path";

const TOOL = join(import.meta.dirname || ".", "../../../technology.local.laptop/scripts.utilities/arxiv.search.articles/arxiv-search.py");

export const app: MobileApp = {
  name: "arxiv",
  icon: "Arxiv",
  messageDescription: "论文搜索: 搜索 xxx [-n 数量]",
  onOpen(state: any) {
    return { screen: [
      "Arxiv 论文搜索",
      "",
      "  搜索 关键词      搜论文 (默认5篇)",
      "  搜索 关键词 -n 10 搜10篇",
      "  返回             回主屏幕",
    ].join("\n"), state };
  },
  async onAction(input: string, state: any) {
    const cmd = input.trim();
    if (cmd === "返回") return { screen: "", state, exit: true };
    if (cmd.startsWith("搜索 ") || cmd.startsWith("search ")) {
      const rest = cmd.replace(/^(搜索 |search )/, "");
      const parts = rest.split(/\s+/);
      let query = "";
      let n = "5";
      for (let i = 0; i < parts.length; i++) {
        if (parts[i] === "-n" && parts[i + 1]) { n = parts[i + 1]; i++; }
        else query += parts[i] + " ";
      }
      query = query.trim();
      if (!query) return { screen: "用法: 搜索 <关键词> [-n N]", state };
      try {
        const r = execSync(`python3 "${TOOL}" "${query}" -n ${n}`, { encoding: "utf8", timeout: 15000 });
        return { screen: r || "(无结果)", state };
      } catch (e: any) {
        return { screen: `搜索失败: ${e.stderr || e.message}`, state };
      }
    }
    return { screen: "用法: 搜索 <关键词> [-n N] | 返回", state };
  },
};
