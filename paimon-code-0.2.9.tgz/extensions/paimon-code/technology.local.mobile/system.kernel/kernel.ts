import { runtimeCacheDir, DIRS, PROGRAM_FILES_MOBILE, appPersonDir, setApiAgent } from "#paths";
import { Text } from "@earendil-works/pi-tui";
// system.kernel/kernel.ts - 手机内核 // 2026-06-20-0841
// 唯一注册的 tool: mobile。状态机 + app 路由 + 通知 + 提醒检查。
// 所有 app 通过 registerApp() 接入。apps.json 是唯一真相源。

import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { loadReminders, isOverdue, needsNudge } from "../apps/reminder/reminder.ts";
import { registerTerminal } from "#hands_terminal";
import { startGameServer } from "../system.server/game-server.ts";
import path from "node:path";
import { writeFileSync, readFileSync, readdirSync, existsSync, mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { homedir } from "node:os";

// ── i18n 辅助：根据 globalThis.__paimonLang 返回对应语言文本 ──
function t(zh: string, en: string): string {
  return ((globalThis as any).__paimonLang === "zh") ? zh : en;
}
import { registerPaimonTool, sendCustomMessage, resultContent } from "#kernel_backbone";
import { renderToolCall, renderMessage } from "#tui_blockrender";
import { personDataDir as getPersonDir } from "#paths";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
const _require = createRequire(import.meta.url);
import { exec, execSync } from "node:child_process";

// ── 浏览器服务（Safari 动态渲染用）──
const BROWSER_PORT = process.env.BROWSER_PORT ? Number(process.env.BROWSER_PORT) : 0;
const PORT_FILE = `${homedir()}/.paimon/browser-service.port`;
function readBrowserUrl(): string {
  try { const port = readFileSync(PORT_FILE, "utf8").trim(); if (port) return `http://127.0.0.1:${port}`; } catch {}
  return `http://127.0.0.1:${BROWSER_PORT}`;
}
let _browserPid: number | null = null;
let _browserReady = false;
let _browserStarting = false;

function startBrowserIfNeeded(): void {
  if (_browserReady || _browserStarting) return;
  _browserStarting = true;
  const svcPath = path.resolve(fileURLToPath(import.meta.url), "../../../technology.cloud.servers/browser-service.cjs");
  if (!existsSync(svcPath)) { _browserStarting = false; return; }
  // 先异步检查是否已经跑着
  fetch(readBrowserUrl(), { signal: AbortSignal.timeout(500) })
    .then(() => { _browserReady = true; _browserStarting = false; })
    .catch(() => {
      // 没跑，启动
      const child = exec(`node ${JSON.stringify(svcPath)}`, { env: { ...process.env, BROWSER_PORT: String(BROWSER_PORT) } });
      _browserPid = child.pid ?? null;
      child.unref();
      const poll = (n: number) => {
        if (n <= 0) { _browserStarting = false; return; }
        setTimeout(() => {
          fetch(readBrowserUrl(), { signal: AbortSignal.timeout(500) })
            .then(() => { _browserReady = true; _browserStarting = false; })
            .catch(() => poll(n - 1));
        }, 500);
      };
      poll(20);
    });
}

export function browserStatus(): string {
  if (_browserReady) return "dynamic (JS rendering)";
  if (_browserStarting) return "loading...";
  return "static (text only)";
}
export function isBrowserReady(): boolean { return _browserReady; }

// ── App 接口 ──

export interface MobileApp {
  name: string;
  icon: string;
  messageDescription: string;
  onOpen(state: any, personDir: string): { screen: string; state: any } | Promise<{ screen: string; state: any }>;
  onAction(input: string, state: any, personDir: string): Promise<{ screen: string; state: any }> | { screen: string; state: any };
}

// ── 状态（持久化到磁盘，extension 重载不丢）──

interface MobileState {
  currentApp: string | null;
  appStates: Record<string, any>;
  notifications: { from: string; text: string; ts: number }[];
  notificationMode: string;
  installedApps: { name: string; desc: string }[];
  devMode: boolean;
}

let _stateFile = "";
let _lastScreen = ""; // I3: 追踪最后渲染的屏幕文本，供截图命令使用
let _recording = false; // I3: 录屏状态
let _recFrames: any[] = []; // I3: 录屏帧缓存
const state: MobileState = {
  currentApp: null,
  appStates: {},
  notifications: [],
  notificationMode: "normal",
  installedApps: [],
  devMode: false,
};

function loadState() {
  if (!_stateFile) return;
  try {
    const saved = JSON.parse(readFileSync(_stateFile, "utf8"));
    state.currentApp = saved.currentApp ?? null;
    state.appStates = saved.appStates ?? {};
    state.notifications = saved.notifications ?? [];
    state.notificationMode = saved.notificationMode ?? "normal";
    state.devMode = saved.devMode ?? false;
  } catch {}
}

function saveState(screen?: string) {
  if (screen) _lastScreen = screen;
  if (!_stateFile) return;
  try {
    mkdirSync(dirname(_stateFile), { recursive: true });
    writeFileSync(_stateFile, JSON.stringify(state));
    if (screen) {
      writeFileSync(_stateFile.replace('-state.json', '-screen.txt'), screen);
      // I3: 录屏中自动捕获帧
      if (_recording) {
        _recFrames.push({ ts: Date.now(), app: state.currentApp || "主屏幕", screen });
      }
    }
  } catch {}
}

const apps: Map<string, MobileApp> = new Map();
const _loadCache = new Map<string, { app: MobileApp; ts: number }>();

// ── Per-agent app 注册表 ──
let _agentAppsFile = "";
let _agentAppList: string[] | null = null;

function loadAgentApps(id: string) {
  _agentAppsFile = path.join(appPersonDir(id, "mobile"), "apps.json");
  try {
    _agentAppList = JSON.parse(readFileSync(_agentAppsFile, "utf8")).apps;
  } catch {
    _agentAppList = null;
  }
}

function saveAgentApps() {
  if (!_agentAppsFile) return;
  try {
    mkdirSync(dirname(_agentAppsFile), { recursive: true });
    writeFileSync(_agentAppsFile, JSON.stringify({ apps: _agentAppList }, null, 2));
  } catch {}
}

function isAppAllowed(appDirName: string): boolean {
  if (!_agentAppList) return true;
  return _agentAppList.includes(appDirName);
}

export function addAgentApp(dirName: string) {
  if (!_agentAppList) _agentAppList = [];
  if (!_agentAppList.includes(dirName)) _agentAppList.push(dirName);
  saveAgentApps();
}

export function removeAgentApp(dirName: string) {
  if (!_agentAppList) return;
  _agentAppList = _agentAppList.filter(d => d !== dirName);
  saveAgentApps();
}
// ── 动态加载 App（dev mode 下每次用 ?t= 绕过 Node ESM 缓存）──
async function loadApp(name: string): Promise<MobileApp | undefined> {
  // devMode 从 settings.json 实时读取，不用 state（state 是启动快照）
  let dm = false;
  try { const sf = JSON.parse(readFileSync(path.join(homedir(), ".paimon/agent/config/settings.json"), "utf8")); dm = !!sf.developerMode; } catch {}
  if (!dm) return apps.get(name);
  // Session 级缓存：5s TTL，超时重新加载
  const hit = _loadCache.get(name);
  if (hit && Date.now() - hit.ts < 5000) return hit.app;
  if (existsSync(PROGRAM_FILES_MOBILE)) {
    for (const appFolder of readdirSync(PROGRAM_FILES_MOBILE)) {
      if (appFolder.startsWith(".") || appFolder.startsWith("@FUTURE.") || appFolder.startsWith("@removed.")) continue;
      if (!isAppAllowed(appFolder)) continue;
      const appDir = path.join(PROGRAM_FILES_MOBILE, appFolder);
      try {
        const candidates = readdirSync(appDir).filter((f: string) => f.endsWith(".ts") && !f.includes(".SPEC") && !f.includes(".CHANGELOG") && !f.includes(".test") && !f.includes("test.ts"));
        for (const file of candidates) {
          try {
            const fullPath = path.join(appDir, file);
            try { const req = createRequire(import.meta.url); delete req.cache[req.resolve(fullPath)]; } catch {}
            const mod = await import(fullPath + `?t=${Date.now()}`);
            if (mod.app && mod.app.name === name) {
              _loadCache.set(name, { app: mod.app, ts: Date.now() });
              registerApp(mod.app);
              return mod.app;
            }
          } catch {}
        }
      } catch {}
    }
  }
  // dev mode fallback
  const fb = apps.get(name);
  if (fb) _loadCache.set(name, { app: fb, ts: Date.now() });
  return fb;
}


// ── App 注册 ──

export function registerApp(app: MobileApp) {
  apps.set(app.name, app);
  // 同步到 state，供 CLI 渲染
  if (!state.installedApps) state.installedApps = [];
  if (!state.installedApps.find((a: any) => a.name === app.name)) {
    state.installedApps.push({ name: app.name, desc: app.messageDescription });
  }
}

// ── 通知 ──

export function pushNotification(text: string) {
  state.notifications.push({ from: "系统", text, ts: Date.now() });
  if (state.notifications.length > 50) state.notifications.shift();
}

// ── 屏幕渲染 ──

import { logerr } from "#paths";

// 终端可见宽度：CJK/emoji 约占 2 列，ASCII 占 1 列
function vw(s: string): number {
  let w = 0;
  for (const ch of s) {
    const c = ch.codePointAt(0)!;
    if (c >= 0x4e00 && c <= 0x9fff || c >= 0x3000 && c <= 0x303f || c >= 0xff00 && c <= 0xffef) w += 2;
    else if (c > 0x7f && c < 0x2000) w += 1;
    else w += 1;
  }
  return w;
}

function padR(s: string, w: number): string { return s + " ".repeat(Math.max(0, w - vw(s))); }

function renderHome(): string {
  const allApps = [...apps.values()];
  const COLS = 3;
  const GAP = 2;
  // 按列计算最大宽度
  const colW = [0, 0, 0];
  for (let i = 0; i < allApps.length; i++) {
    const col = i % COLS;
    const w = vw(` ${allApps[i].name} `);
    if (w > colW[col]) colW[col] = w;
  }
  const innerW = colW[0] + (colW[1] > 0 ? GAP + colW[1] : 0) + (colW[2] > 0 ? GAP + colW[2] : 0);
  const hr = "─".repeat(Math.max(innerW, 10));

  const lines: string[] = [];
  lines.push(`┌${hr}┐`);
  lines.push(`│${padR("📱 iPhone", innerW)}│`);
  lines.push(`├${hr}┤`);

  for (let i = 0; i < allApps.length; i += COLS) {
    const cells: string[] = [];
    for (let col = 0; col < COLS; col++) {
      const app = allApps[i + col];
      if (app) cells.push(padR(` ${app.name}`, colW[col]));
      else cells.push(" ".repeat(colW[col] || 1));
    }
    lines.push(`│${cells.join(" ".repeat(GAP))}│`);
  }

  lines.push(`├${hr}┤`);
  const mode = state.notificationMode || "normal";
  const unread = (state.notifications || []).length;
  lines.push(`│${padR(unread > 0 ? ` 🔴 ${unread}条通知 | 输入「通知」查看` : " 无新通知", innerW)}│`);
  lines.push(`│${padR(` 模式: ${mode}`, innerW)}│`);
  lines.push(`└${hr}┘`);
  return lines.join("\n");
}

function renderNotifications(): string {
  const lines = ["═══ 通知中心 ═══", ""];
  if (state.notifications.length === 0) {
    lines.push("  (无通知)");
  } else {
    for (const n of state.notifications.slice(-10)) {
      lines.push(`    [${n.from}] ${n.text}`);
    }
  }
  lines.push("");
  lines.push("输入「清除通知」清除全部 | 「返回」回主屏幕");
  return lines.join("\n");
}

// ── 输入路由 ──

function findApp(input: string): MobileApp | null {
  const lower = input.toLowerCase().trim();
  for (const [, app] of apps) {
    if (lower === app.name.toLowerCase() || lower === app.icon.toLowerCase()) return app;
  }
  return null;
}

function isBack(input: string): boolean {
  return /^(返回|back|主页|home|退出|exit|主屏幕)$/i.test(input.trim());
}

async function handleInput(input: string, personDir: string): Promise<string> {
  const trimmed = input.trim();
  const lower = trimmed.toLowerCase();

  if (isBack(trimmed)) {
    state.currentApp = null;
    saveState();
    const s = renderHome(); _lastScreen = s; return s;
  }

  if (/^(截图|截屏|screenshot)$/i.test(trimmed)) {
    try {
      const photosDir = path.join(homedir(), ".paimon/AppData/shared/photos");
      mkdirSync(photosDir, { recursive: true });
      const fn = `mobilepic_${Date.now()}.mobilepic`;
      const snap: any = { type: "mobilepic", ts: Date.now(), app: state.currentApp || "主屏幕", screen: _lastScreen || "(空)" };
      writeFileSync(path.join(photosDir, fn), JSON.stringify(snap, null, 2));
      return `截图已保存: ${fn}\n\n打开「相册」app 浏览。`;
    } catch (e: any) { return "截图失败: " + e.message; }
  }

  // I3: 录屏 — 开始/停止
  if (/^(开始录屏|录屏|record)$/i.test(trimmed)) {
    if (_recording) return "已在录屏中。输入「停止录屏」结束。";
    _recording = true;
    _recFrames = [];
    // 捕获当前屏幕作为第一帧
    if (_lastScreen) _recFrames.push({ ts: Date.now(), app: state.currentApp || "主屏幕", screen: _lastScreen });
    return "录屏已开始。操作完成后输入「停止录屏」保存。";
  }
  if (/^(停止录屏|stop)$/i.test(trimmed)) {
    if (!_recording) return "当前未在录屏。输入「开始录屏」开始。";
    _recording = false;
    try {
      const photosDir = path.join(homedir(), ".paimon/AppData/shared/photos");
      mkdirSync(photosDir, { recursive: true });
      const fn = `mobilelog_${Date.now()}.mobilelog`;
      const rec: any = {
        type: "mobilelog",
        ts_start: _recFrames[0]?.ts || Date.now(),
        ts_end: Date.now(),
        frames: _recFrames,
      };
      writeFileSync(path.join(photosDir, fn), JSON.stringify(rec, null, 2));
      _recFrames = [];
      return `录屏已保存: ${fn}\n共 ${rec.frames.length} 帧\n\n打开「相册」app 浏览。`;
    } catch (e: any) { return "录屏保存失败: " + e.message; }
  }

  if (/^(通知|notifications?)$/i.test(trimmed)) {
    state.currentApp = null;
    return renderNotifications();
  }

  if (/^(清除通知|clear notifications?)$/i.test(trimmed)) {
    state.notifications = [];
    saveState();
    return "通知已全部清除。";
  }

  // ── 全局快捷: 发消息 <ID> <内容> → 任何地方直接发送，不下钻微信 ──
  const sendMsgMatch = trimmed.match(/^发消息\s+(\S+)\s+(.+)/);
  if (sendMsgMatch) {
    const target = sendMsgMatch[1];
    const text = sendMsgMatch[2];
    if (!text.trim()) return "消息不能为空";
    try {
      const { appendFileSync: afs, mkdirSync: mks } = await import("node:fs");
      const { join } = await import("node:path");
      const wd = join(homedir(), ".paimon/data/appdata/wechat");
      mks(wd, { recursive: true });
      const msg = { from: process.env.PAIMON_AGENT_NAME || "unknown", to: target, text: text.trim(), ts: Date.now() };
      afs(join(wd, "wechat.jsonl"), JSON.stringify(msg) + "\n");
      try { const wd2 = join(homedir(), ".paimon/RuntimeCache", target, "wake"); mks(wd2, { recursive: true }); afs(join(wd2, "wechat.wake"), JSON.stringify({ from: msg.from, ts: Date.now() }) + "\n"); } catch {}
      const ctx = state.currentApp ? ` (当前在 ${state.currentApp})` : "";
      return `📨 已发送给 ${target}${ctx}\n${text.slice(0, 50)}${text.length > 50 ? "..." : ""}`;
    } catch (e: any) { return "发送失败: " + e.message; }
  }

  if (/^(锁屏|lock)$/i.test(trimmed)) {
    state.currentApp = null;
    return "手机已锁定。再次使用 mobile 解锁。";
  }

  // 控制中心：切换通知模式（紧凑面板）
  if (/^(控制中心|control)$/i.test(trimmed)) {
    const mode = state.notificationMode || "normal";
    const normal = mode === "normal" ? "[ON]" : "";
    const focus = mode === "focus" ? "[ON]" : "";
    const dnd = mode === "dnd" ? "[ON]" : "";
    return `Control Center\n\n  ${normal} 正常  ${focus} 专注  ${dnd} 勿扰\n\n  输入 正常/专注/勿扰 切换`;
  }
  if (/^(勿扰|dnd)$/i.test(trimmed)) {
    state.notificationMode = "dnd";
    saveState();
    return "[DND] 勿扰模式 — 通知不会激活 agent";
  }
  if (/^(专注|focus)$/i.test(trimmed)) {
    state.notificationMode = "focus";
    saveState();
    return "[FOCUS] 专注模式 — 仅重要通知激活";
  }
  if (/^(正常|normal)$/i.test(trimmed)) {
    state.notificationMode = "normal";
    saveState();
    return "[ON] 正常模式 — 所有通知激活 agent";
  }

  if (state.currentApp) {
    // 直接切换到另一个 app，不需要先返回主屏幕
    // 仅当输入以 app 名开头时才切换（防止 "发消息 test-safari" 被劫持）
    const switchApp = findApp(trimmed);
    if (switchApp) {
      if (switchApp.name !== state.currentApp &&
          (lower === switchApp.name.toLowerCase() || lower.startsWith(switchApp.name.toLowerCase() + " "))) {
        state.currentApp = switchApp.name;
        const appState = state.appStates[switchApp.name] ?? {};
        const result = await switchApp.onOpen(appState, personDir);
        state.appStates[switchApp.name] = result.state;
        saveState();
        return result.screen;
      }
      // 已在当前 app 内，又输入了同一个 app 名 → 刷新主页，不当地址栏搜索
      if (switchApp.name === state.currentApp && lower === switchApp.name.toLowerCase()) {
        const appState = state.appStates[switchApp.name] ?? {};
        const result = await switchApp.onOpen(appState, personDir);
        state.appStates[switchApp.name] = result.state;
        saveState();
        return result.screen;
      }
    }
    const app = await loadApp(state.currentApp!);
    if (!app) { state.currentApp = null; saveState(); return renderHome(); }
    const appState = state.appStates[state.currentApp] ?? {};
    const result = await app.onAction(trimmed, appState, personDir);
    state.appStates[state.currentApp] = result.state;
    saveState();
    return result.screen;
  }

  const app = findApp(trimmed);
  if (app) {
    state.currentApp = app.name;
    const appState = state.appStates[app.name] ?? {};
    // Safari 进入时自动启动浏览器服务
    if (app.name === "Safari") {
      startBrowserIfNeeded();
      const result = await app.onOpen(appState, personDir);
      state.appStates[app.name] = result.state;
      saveState();
      const mode = _browserReady ? "🟢 dynamic" : _browserStarting ? "🟡 loading..." : "⚪ static";
      return result.screen + "\n  mode: " + mode;
    }
    const result = await app.onOpen(appState, personDir);
    state.appStates[app.name] = result.state;
    saveState();
    return result.screen;
  }

  return renderHome() + "\n\n没有找到「" + trimmed + "」，请从上面选择一个 app。";
}

// ── 入口 ──

export default function (pi: ExtensionAPI) {
  let personDir: string | null = null;
  let registered = false;

  pi.on("session_start", async (_event, ctx) => {
    // if (registered) return; // 调试：允许重注册，打 jiti 缓存绕过
    const sf = (ctx as any).sessionManager?.getSessionFile?.();
    if (!sf) return;
    personDir = getPersonDir(sf);
    if (!personDir) return;
    const id = personDir.match(/[a-f0-9]+$/)?.[0] || 'x';
    setApiAgent(id);
    _stateFile = path.join(runtimeCacheDir(id), "mobile-state.json");
    loadState();
    loadAgentApps(id);

    // 游戏联机服务器（幂等，已运行则跳过）
    if (!sf.includes("metaconsciousnessSessions") && !sf.includes("HippocampusSessions") && !sf.includes("SleepSessions")) {
      startGameServer();
    }

    // 轮询 WeChat 共享文件，收到新消息时 steer 激活 agent
    // 启动时先跳到当前末尾，避免把历史消息当新通知 flood
    const MSG_FILE = path.join(homedir(), ".paimon/AppData/shared/wechat/wechat.jsonl");
    let _lastMsgLine = 0;
    try {
      const existing = readFileSync(MSG_FILE, "utf8");
      _lastMsgLine = existing.trim().split("\n").filter(Boolean).length;
    } catch {}
    const pollMsgs = () => {
      try {
        const raw = readFileSync(MSG_FILE, "utf8");
        const lines = raw.trim().split("\n").filter(Boolean);
        const name = process.env.PAIMON_AGENT_NAME || "";
        for (let i = _lastMsgLine; i < lines.length; i++) {
          try {
            const m = JSON.parse(lines[i]);
            // 检查是否是发给我的群组消息
            let inGroup = false;
            let groupName = "";
            if (m.to.startsWith("group:")) {
              try {
                const gid = m.to.replace(/^(group:)+/, "");
                const gf = path.join(homedir(), ".paimon/AppData/shared/wechat/groups", `${gid}.json`);
                if (existsSync(gf)) {
                  const g = JSON.parse(readFileSync(gf, "utf8"));
                  inGroup = g.members?.includes(name) || false;
                  groupName = g.name || gid;
                }
              } catch {}
            }
            if (m.to === name || m.to === "all" || m.to === id || inGroup) {
              const preview = (m.text || "").slice(0, 80);
              if (state.notificationMode !== "dnd") {
                try {
                  const feedContent = `[Notification from WeChat] Message from ${m.from}: ${m.text}`;
                  sendCustomMessage(pi, "mobile-notification", feedContent, { app: "WeChat", from: m.from, text: m.text, group: inGroup ? groupName : "" });
                } catch {}
              }
              state.notifications = state.notifications || [];
              state.notifications.unshift({ from: m.from, text: preview, ts: Date.now() });
              if (state.notifications.length > 50) state.notifications.length = 50;
            }
          } catch {}
        }
        _lastMsgLine = lines.length;
      } catch {}
    };
    setInterval(pollMsgs, 5000);
    // 延迟到第一个 before_agent_start 后执行，确保 memory snapshot 已注入前缀（否则 cache miss）
    let _pollStarted = false;
    pi.on("before_agent_start", () => {
      if (!_pollStarted) { _pollStarted = true; pollMsgs(); }
    });

    // ── mobile-notification 渲染器 ──
    pi.registerMessageRenderer("mobile-notification", (message, _opts, theme) => {
      const d = (message.details || {}) as any;
      const from = d.from || "unknown";
      const msgText = (d.text as string) || String(message.content || "");
      const label = `Notification from WeChat`;
      const body = `  Message from ${from}: ${msgText}`;
      return renderMessage.alert(theme, {}, label, body);
    });

    pi.registerMessageRenderer("reminder-check", (message, _opts, theme) => {
      const c = message.content;
      const body = typeof c === "string" ? c : Array.isArray(c) ? c.filter((b:any)=>b.type==="text").map((b:any)=>b.text).join("\n") : String(c??"");
      return renderMessage.notice(theme, "Reminder", body);
    });

    // ── 终端工具 ──
    registerTerminal(pi);

    // ── App 自动发现：扫描 ProgramFiles/Mobile/，按 agent 注册表过滤 ──
    const firstRun = _agentAppList === null;
    const discoveredDirs: string[] = [];
    if (existsSync(PROGRAM_FILES_MOBILE)) {
      for (const appFolder of readdirSync(PROGRAM_FILES_MOBILE)) {
        if (appFolder.startsWith(".") || appFolder.startsWith("@FUTURE.") || appFolder.startsWith("@removed.")) continue;
        if (!isAppAllowed(appFolder)) continue;
        const appDir = path.join(PROGRAM_FILES_MOBILE, appFolder);
        try {
          const candidates = readdirSync(appDir).filter((f: string) => f.endsWith(".ts") && !f.includes(".SPEC") && !f.includes(".CHANGELOG") && !f.includes(".test") && !f.includes("test.ts"));
          for (const file of candidates) {
            try {
              const mod = await import(path.join(appDir, file) + `?t=${Date.now()}`);
              if (mod.app && mod.app.name && mod.app.onOpen && mod.app.onAction) {
                registerApp(mod.app);
                discoveredDirs.push(appFolder);
                break;
              }
            } catch (e) { /* app import failed */ }
          }
        } catch (e) { /* app dir scan failed */ }
      }
    }
    if (firstRun && discoveredDirs.length > 0) {
      _agentAppList = discoveredDirs;
      saveAgentApps();
    }
    saveState(); // 保存 installedApps
  });

  // ── 注册 mobile tool（顶层，不在 session_start 里——必须在 before_agent_start 之前注册）──
  let _mobileQueue: Promise<any> = Promise.resolve();

  registerPaimonTool({
    name: "mobile",
    label: "Mobile",
    messageDescription: "手机 - 打开查看主屏幕，输入 app 名字打开应用，在应用内操作",
    promptSnippet: "Use your mobile: open apps, check notifications, play games, browse web",
    parameters: {
      type: "object" as any,
      properties: {
        input: { type: "string", messageDescription: "操作内容（app名/动作/返回）。空=查看当前屏幕" },
      },
    },
    renderCall(args: any, theme: any) {
      return renderToolCall.command(theme, "Mobile", args?.input);
    },
    renderResult(result: any, _options: any, theme: any, ctx: any) {
      if (result?.details?.loading) return renderMessage.spinner();
      return renderMessage.output(theme, ctx, resultContent(result));
    },
    async execute(_id: string, args: any) {
      const input = String(args?.input ?? "").trim();
      const t0 = Date.now();
      if (!input) {
        if (state.currentApp) {
          const app = await loadApp(state.currentApp!);
          if (app) {
            const result = await app.onOpen(state.appStates[state.currentApp] ?? {}, personDir!);
            const screen = result.screen || "(无返回内容)";
            saveState(screen);
            return { content: [{ type: "text", text: screen }], details: {} };
          }
        }
        const homeScreen = renderHome();
        saveState(homeScreen);
        return { content: [{ type: "text", text: homeScreen }], details: {} };
      }
      const pd = personDir!;
      const fastResult = await Promise.race([
        handleInput(input, pd).then(screen => ({ screen: screen || "(无返回)" })),
        new Promise(r => setTimeout(() => r(null), 100)),
      ]);
      if (fastResult) {
        const screen = (fastResult as any).screen;
        saveState(screen);
        return { content: [{ type: "text", text: screen }], details: {} };
      }
      _mobileQueue = _mobileQueue.then(() => handleInput(input, pd)).then((screen) => {
        screen = screen || "(无返回)";
        saveState(screen);
        const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
        try {
          sendCustomMessage(pi, "continuous-cmd-done", `Mobile 完成 (${elapsed}s):\n${screen.slice(0, 8000)}`);
        } catch {}
      }).catch(() => {});
      const label = input.startsWith("http") ? input : (input.length > 80 ? input.slice(0, 77) + "..." : input);
      return { content: [{ type: "text", text: `Mobile 加载中... (${label})` }], details: { loading: true } };
    },
  });
}

